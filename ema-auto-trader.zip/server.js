/**
 * EMA Auto-Trader — runs 24/7 on a free cloud host, trades through the Deriv API
 * (no MT5 terminal, no VPS, no MetaApi).
 *
 * Strategy: on every CLOSED candle
 *   close > EMA  -> be long  (MULTUP)   — closes an open short first
 *   close < EMA  -> be short (MULTDOWN) — closes an open long first
 * One position at a time. First trade happens at the first candle close after Start.
 */
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');
const { emaSeries } = require('./ema');

const PORT = process.env.PORT || 3000;
const DERIV_TOKEN = process.env.DERIV_TOKEN;
const APP_ID = process.env.DERIV_APP_ID || '1089';
const DASH_PASSWORD = process.env.DASHBOARD_PASSWORD;
const DATA_FILE = path.join(process.env.DATA_DIR || __dirname, 'bot-state.json');

const GRANULARITIES = [60, 120, 180, 300, 600, 900, 1800, 3600, 7200, 14400, 28800, 86400];

// ---------------------------------------------------------------- state
const state = {
  connected: false,
  authorized: false,
  account: null, // { loginid, isVirtual, currency }
  balance: null,
  config: {
    symbol: 'R_100',
    granularity: 60,
    emaPeriod: 20,
    stake: 1,
    multiplier: null,
    stopLoss: 0,
    takeProfit: 0,
    confirmReal: false,
  },
  running: false,
  position: null, // { contractId, side, buyPrice, profit, openedAt, symbol }
  lastSignal: null,
  logs: [],
  trades: [],
};
let candles = []; // [{open_time, open, high, low, close}] — last item is the forming candle
let candleSubId = null;
let busy = false;

function log(msg, level = 'info') {
  const entry = { t: Date.now(), level, msg };
  state.logs.unshift(entry);
  state.logs.length = Math.min(state.logs.length, 200);
  console.log(`[${new Date().toISOString()}] ${level.toUpperCase()} ${msg}`);
  broadcast();
}

function persist() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ config: state.config, running: state.running, trades: state.trades }));
  } catch (e) { /* ephemeral disk is fine */ }
}
function restore() {
  try {
    const d = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    Object.assign(state.config, d.config || {});
    state.trades = d.trades || [];
    return !!d.running;
  } catch (e) { return false; }
}

// ---------------------------------------------------------------- Deriv client
class Deriv extends EventEmitter {
  constructor() {
    super();
    this.ws = null;
    this.reqId = 1;
    this.pending = new Map();
    this.backoff = 3000;
  }

  connect() {
    this.ws = new WebSocket(`wss://ws.derivws.com/websockets/v3?app_id=${APP_ID}`);
    this.ws.on('open', async () => {
      state.connected = true;
      this.backoff = 3000;
      this.pingTimer = setInterval(() => this.send({ ping: 1 }).catch(() => {}), 30000);
      log('Connected to Deriv');
      if (!DERIV_TOKEN) return log('DERIV_TOKEN env var is missing', 'error');
      try {
        const a = await this.send({ authorize: DERIV_TOKEN });
        state.account = {
          loginid: a.authorize.loginid,
          isVirtual: !!a.authorize.is_virtual,
          currency: a.authorize.currency,
        };
        state.balance = a.authorize.balance;
        state.authorized = true;
        log(`Authorized ${state.account.loginid} (${state.account.isVirtual ? 'DEMO' : 'REAL'})`);
        this.send({ balance: 1, subscribe: 1 }).catch(() => {});
        this.emit('authorized');
      } catch (e) {
        log(`Authorize failed: ${e.message}`, 'error');
      }
    });
    this.ws.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw); } catch { return; }
      if (m.req_id && this.pending.has(m.req_id)) {
        const p = this.pending.get(m.req_id);
        this.pending.delete(m.req_id);
        if (m.error) p.reject(Object.assign(new Error(m.error.message), { code: m.error.code }));
        else p.resolve(m);
      }
      this.emit('message', m);
    });
    this.ws.on('close', () => {
      clearInterval(this.pingTimer);
      state.connected = false;
      state.authorized = false;
      candleSubId = null;
      log(`Disconnected. Reconnecting in ${this.backoff / 1000}s`, 'warn');
      setTimeout(() => this.connect(), this.backoff);
      this.backoff = Math.min(this.backoff * 2, 30000);
    });
    this.ws.on('error', (e) => console.error('WS error', e.message));
  }

  send(obj, timeout = 20000) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return reject(new Error('Not connected'));
      const id = this.reqId++;
      obj.req_id = id;
      const t = setTimeout(() => { this.pending.delete(id); reject(new Error('Request timeout')); }, timeout);
      this.pending.set(id, {
        resolve: (m) => { clearTimeout(t); resolve(m); },
        reject: (e) => { clearTimeout(t); reject(e); },
      });
      this.ws.send(JSON.stringify(obj));
    });
  }
}
const deriv = new Deriv();

// ---------------------------------------------------------------- bot logic
async function subscribeCandles() {
  const { symbol, granularity, emaPeriod } = state.config;
  if (candleSubId) { deriv.send({ forget: candleSubId }).catch(() => {}); candleSubId = null; }
  const count = Math.min(5000, Math.max(300, emaPeriod * 10));
  const r = await deriv.send({
    ticks_history: symbol,
    adjust_start_time: 1,
    count,
    end: 'latest',
    style: 'candles',
    granularity,
    subscribe: 1,
  });
  candleSubId = r.subscription && r.subscription.id;
  candles = (r.candles || []).map((c) => ({ open_time: c.epoch, open: +c.open, high: +c.high, low: +c.low, close: +c.close }));
  log(`Watching ${symbol} ${granularity / 60}m — ${candles.length} candles loaded`);
}

function onOhlc(o) {
  if (!state.running) return;
  if (o.granularity !== state.config.granularity || o.symbol !== state.config.symbol) return;
  const c = { open_time: o.open_time, open: +o.open, high: +o.high, low: +o.low, close: +o.close };
  const last = candles[candles.length - 1];
  if (last && last.open_time === c.open_time) {
    candles[candles.length - 1] = c; // forming candle update
  } else {
    // new candle began => previous candle is now CLOSED
    const closed = candles.slice();
    candles.push(c);
    if (candles.length > 5000) candles.shift();
    evaluate(closed).catch((e) => log(`Evaluate error: ${e.message}`, 'error'));
  }
  broadcastSoon();
}

async function evaluate(closed) {
  if (busy || !state.running) return;
  const { emaPeriod } = state.config;
  if (closed.length < emaPeriod) return log('Not enough candles for EMA yet', 'warn');
  const closes = closed.map((c) => c.close);
  const ema = emaSeries(closes, emaPeriod).pop();
  const close = closes[closes.length - 1];
  const side = close > ema ? 'BUY' : close < ema ? 'SELL' : null;
  state.lastSignal = { t: Date.now(), close, ema, side };
  log(`Candle closed ${close} vs EMA${emaPeriod} ${ema.toFixed(5)} → ${side || 'no signal'}`);
  if (!side) return;
  if (state.position && state.position.side === side) return; // already positioned correctly

  busy = true;
  try {
    if (state.position) await closePosition('signal flip');
    await openPosition(side);
  } finally {
    busy = false;
    broadcast();
  }
}

async function openPosition(side) {
  const { symbol, stake, multiplier, stopLoss, takeProfit } = state.config;
  if (!multiplier) return log('No multiplier selected — cannot open trade', 'error');
  const parameters = {
    amount: stake,
    basis: 'stake',
    contract_type: side === 'BUY' ? 'MULTUP' : 'MULTDOWN',
    currency: state.account.currency,
    multiplier,
    symbol,
  };
  const limit_order = {};
  if (stopLoss > 0) limit_order.stop_loss = stopLoss;
  if (takeProfit > 0) limit_order.take_profit = takeProfit;
  if (Object.keys(limit_order).length) parameters.limit_order = limit_order;
  try {
    const r = await deriv.send({ buy: 1, price: stake, parameters });
    state.position = {
      contractId: r.buy.contract_id,
      side,
      buyPrice: r.buy.buy_price,
      profit: 0,
      openedAt: Date.now(),
      symbol,
    };
    log(`${side} opened on ${symbol}, stake ${r.buy.buy_price}, contract ${r.buy.contract_id}`, 'trade');
    trackContract(r.buy.contract_id);
  } catch (e) {
    log(`Buy failed: ${e.message}`, 'error');
  }
}

function trackContract(id) {
  deriv.send({ proposal_open_contract: 1, contract_id: id, subscribe: 1 }).catch((e) => log(`Track failed: ${e.message}`, 'error'));
}

async function closePosition(reason) {
  const p = state.position;
  if (!p) return;
  try {
    const r = await deriv.send({ sell: p.contractId, price: 0 });
    log(`Closed ${p.side} (${reason}) at ${r.sell.sold_for}`, 'trade');
    recordTrade(p, r.sell.sold_for - p.buyPrice, reason);
    state.position = null;
  } catch (e) {
    log(`Sell failed: ${e.message}`, 'error');
    throw e;
  }
}

function recordTrade(p, pnl, reason) {
  state.trades.unshift({ t: Date.now(), symbol: p.symbol, side: p.side, pnl: +pnl.toFixed(2), reason });
  state.trades.length = Math.min(state.trades.length, 100);
  persist();
}

// open-contract updates (detects stop-loss / take-profit hits made by the broker)
function onContract(c) {
  const p = state.position;
  if (!p || c.contract_id !== p.contractId) return;
  p.profit = c.profit;
  if (c.is_sold) {
    if (state.position) {
      recordTrade(p, c.profit, c.status === 'sold' ? 'closed' : `auto-${c.status}`);
      log(`Position ${p.side} ended (${c.status}) P/L ${c.profit}`, 'trade');
      state.position = null;
    }
  }
  broadcastSoon();
}

deriv.on('message', (m) => {
  if (m.msg_type === 'ohlc') onOhlc(m.ohlc);
  else if (m.msg_type === 'proposal_open_contract' && m.proposal_open_contract) onContract(m.proposal_open_contract);
  else if (m.msg_type === 'balance' && m.balance) { state.balance = m.balance.balance; broadcastSoon(); }
});

deriv.on('authorized', async () => {
  if (state.running) {
    try {
      await subscribeCandles();
      if (state.position) trackContract(state.position.contractId);
    } catch (e) { log(`Resubscribe failed: ${e.message}`, 'error'); }
  }
});

async function startBot() {
  if (!state.authorized) throw new Error('Not connected/authorized to Deriv yet');
  if (!state.account.isVirtual && !state.config.confirmReal)
    throw new Error('This is a REAL account — tick the confirmation box first');
  if (!state.config.multiplier) throw new Error('Pick a multiplier (load symbol first)');
  state.running = true;
  persist();
  await subscribeCandles();
  log('Bot STARTED — first trade at next candle close', 'trade');
}

async function stopBot(closePos) {
  state.running = false;
  if (candleSubId) { deriv.send({ forget: candleSubId }).catch(() => {}); candleSubId = null; }
  if (closePos && state.position) { try { await closePosition('bot stopped'); } catch (e) { /* logged */ } }
  persist();
  log('Bot STOPPED', 'trade');
}

// ---------------------------------------------------------------- web server
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ ok: true, running: state.running, connected: state.connected }));

const sessions = new Map(); // token -> expiry
let failedLogins = 0;
app.post('/api/login', async (req, res) => {
  if (!DASH_PASSWORD) return res.status(500).json({ error: 'DASHBOARD_PASSWORD env var not set' });
  const ok = typeof req.body.password === 'string' &&
    req.body.password.length === DASH_PASSWORD.length &&
    crypto.timingSafeEqual(Buffer.from(req.body.password), Buffer.from(DASH_PASSWORD));
  if (!ok) {
    failedLogins++;
    await new Promise((r) => setTimeout(r, Math.min(failedLogins * 500, 5000)));
    return res.status(401).json({ error: 'Wrong password' });
  }
  failedLogins = 0;
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, Date.now() + 7 * 864e5);
  res.json({ token });
});

function validToken(t) {
  const exp = sessions.get(t);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(t); return false; }
  return true;
}
function auth(req, res, next) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  if (!validToken(t)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(400).json({ error: e.message }));

let symbolCache = null;
app.get('/api/symbols', auth, wrap(async (_req, res) => {
  if (!symbolCache) {
    const r = await deriv.send({ active_symbols: 'brief', product_type: 'basic' });
    symbolCache = r.active_symbols
      .filter((s) => !s.is_trading_suspended)
      .map((s) => ({ symbol: s.symbol, name: s.display_name, market: s.market_display_name }));
    setTimeout(() => (symbolCache = null), 3600e3);
  }
  res.json(symbolCache);
}));

app.get('/api/contracts', auth, wrap(async (req, res) => {
  const r = await deriv.send({ contracts_for: String(req.query.symbol), currency: state.account.currency, product_type: 'basic' });
  const m = (r.contracts_for.available || []).find((c) => c.contract_type === 'MULTUP');
  res.json({ multipliers: m ? m.multiplier_range : [] });
}));

app.post('/api/config', auth, wrap(async (req, res) => {
  const b = req.body;
  if (state.running) throw new Error('Stop the bot before changing settings');
  if (typeof b.symbol !== 'string' || !/^[A-Za-z0-9_]+$/.test(b.symbol)) throw new Error('Bad symbol');
  if (!GRANULARITIES.includes(+b.granularity)) throw new Error('Bad timeframe');
  if (!(+b.emaPeriod >= 2 && +b.emaPeriod <= 500)) throw new Error('EMA period must be 2–500');
  if (!(+b.stake > 0)) throw new Error('Stake must be > 0');
  if (+b.stopLoss < 0 || +b.takeProfit < 0) throw new Error('SL/TP cannot be negative');
  state.config = {
    symbol: b.symbol,
    granularity: +b.granularity,
    emaPeriod: Math.round(+b.emaPeriod),
    stake: +b.stake,
    multiplier: b.multiplier ? +b.multiplier : null,
    stopLoss: +b.stopLoss || 0,
    takeProfit: +b.takeProfit || 0,
    confirmReal: !!b.confirmReal,
  };
  persist();
  broadcast();
  res.json({ ok: true });
}));

app.post('/api/start', auth, wrap(async (_req, res) => { await startBot(); res.json({ ok: true }); }));
app.post('/api/stop', auth, wrap(async (req, res) => { await stopBot(!!req.body.closePosition); res.json({ ok: true }); }));

// ---------------------------------------------------------------- live updates to browser
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/live' });
const clients = new Set();

function snapshot() {
  const view = candles.slice(-120);
  const closes = candles.map((c) => c.close);
  const ema = emaSeries(closes, state.config.emaPeriod).slice(-view.length);
  return {
    type: 'state',
    connected: state.connected,
    authorized: state.authorized,
    account: state.account,
    balance: state.balance,
    config: state.config,
    running: state.running,
    position: state.position,
    lastSignal: state.lastSignal,
    logs: state.logs.slice(0, 40),
    trades: state.trades.slice(0, 30),
    chart: { close: view.map((c) => c.close), ema },
  };
}
function broadcast() {
  if (!clients.size) return;
  const msg = JSON.stringify(snapshot());
  for (const ws of clients) if (ws.readyState === WebSocket.OPEN) ws.send(msg);
}
let soon = null;
function broadcastSoon() { if (!soon) soon = setTimeout(() => { soon = null; broadcast(); }, 500); }

wss.on('connection', (ws) => {
  let ok = false;
  const kill = setTimeout(() => !ok && ws.close(), 5000);
  ws.on('message', (raw) => {
    try {
      const m = JSON.parse(raw);
      if (m.type === 'auth' && validToken(m.token)) {
        ok = true; clearTimeout(kill); clients.add(ws); ws.send(JSON.stringify(snapshot()));
      } else if (!ok) ws.close();
    } catch { ws.close(); }
  });
  ws.on('close', () => clients.delete(ws));
});

// ---------------------------------------------------------------- boot
const wasRunning = restore();
server.listen(PORT, () => {
  console.log(`Dashboard on :${PORT}`);
  if (!DASH_PASSWORD) console.warn('Set DASHBOARD_PASSWORD or nobody can log in');
  state.running = wasRunning; // resumes automatically once authorized (see 'authorized' handler)
  deriv.connect();
});
