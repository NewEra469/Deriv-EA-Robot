# EMA Auto-Trader (Deriv API, free cloud)

Browser dashboard + 24/7 bot. Buys when a candle closes above your EMA, sells when it closes below.
No MT5 terminal, no VPS, no MetaApi. Trades through the Deriv API using multiplier contracts
(MULTUP = buy, MULTDOWN = sell). Stake replaces "lot size".

## Deploy on Render (free)
1. Create a Deriv **demo** account → app.deriv.com/account/api-token → create a token with **Read + Trade** scopes.
2. Push this folder to a GitHub repo.
3. Render → New → Blueprint (uses `render.yaml`) → set env vars:
   - `DERIV_TOKEN` = your token
   - `DASHBOARD_PASSWORD` = a long password
4. Open the Render URL, log in, pick symbol / timeframe / EMA / stake / multiplier, press Start.

## Keep it awake 24/7
Render free web services sleep after ~15 min without traffic. Create a free UptimeRobot monitor
that pings `https://YOUR-APP.onrender.com/health` every 5 minutes.

## Notes
- Settings persist to disk, but Render free disks are wiped on redeploy → the bot comes back STOPPED. This is intentional.
- After a restart/reconnect the bot resumes watching candles and re-tracks the open position.
- The token decides demo vs real. Real accounts require the confirmation checkbox.
- Test on demo for weeks before risking real money. Multiplier contracts can lose your whole stake; set stop loss.
- Run locally: `npm install && DERIV_TOKEN=xxx DASHBOARD_PASSWORD=yyy npm start`
