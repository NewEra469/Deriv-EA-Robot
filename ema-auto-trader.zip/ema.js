// EMA helpers. Seeds with SMA of the first `period` values, then standard smoothing.
function emaSeries(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += values[i];
  let prev = sum / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

function lastEma(values, period) {
  const s = emaSeries(values, period);
  return s[s.length - 1];
}

module.exports = { emaSeries, lastEma };
