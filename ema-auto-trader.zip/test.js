const assert = require('assert');
const { emaSeries } = require('./ema');

// period 3, k = 0.5. SMA seed of [1,2,3] = 2; next: 4*.5+2*.5 = 3; next: 5*.5+3*.5 = 4
const s = emaSeries([1, 2, 3, 4, 5], 3);
assert.deepStrictEqual(s, [null, null, 2, 3, 4]);
assert.deepStrictEqual(emaSeries([1, 2], 3), [null, null]);
console.log('EMA tests passed');
